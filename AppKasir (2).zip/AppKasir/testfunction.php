<?php

session_start();

//koneksi
$conn = mysqli_connect('localhost','root','','kasir');

//login
if(isset($_POST['login'])){
    $username = $_POST ['username'];
    $password = $_POST ['password'];

    $check = mysqli_query ($conn,"SELECT * FROM user WHERE username='$username' and password='$password' ");
    $hitung = mysqli_num_rows($check);

    if($hitung>0){
        $_SESSION['login'] = 'True';
        header('location:index.php');

    } else {

        echo '
        <script>alert("Username atau Password SALAH");
        window.location.href="login.php"
        </script>
        ';
    }
}


if(isset($_POST['tambahbarang'])){
    $namaProduk = $_POST['namaProduk'];
    $deskripsi = $_POST['deskripsi'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    $insert = mysqli_query($conn, "insert into produk (namaProduk, deskripsi, harga, stok) values 
    ('$namaProduk', '$deskripsi', '$harga', '$stok')");

    if($insert){
        header('location:stok.php');
    } else {
        echo '
        <script>alert(" Gagal Menambah Barang Baru ");
        window.location.href="stok.php"
        </script>
        ';
    }

};
if(isset($_POST['tambahpelanggan'])){
    $namapelanggan = $_POST['namapelanggan'];
    $notelp = $_POST['notelp'];
    $alamat = $_POST['alamat'];

    $insert = mysqli_query($conn, "insert into pelanggan (namapelanggan, notelp, alamat) values 
    ('$namapelanggan', '$notelp', '$alamat')");

    if($insert){
        header('location:pelanggan.php');
    } else {
        echo '
        <script>alert(" Gagal Menambah pelanggan Baru ");
        window.location.href="pelanggan.php"
        </script>
        ';
    }
}
if(isset($_POST['tambahpesanan'])){
    $idpelanggan = $_POST['idpelanggan'];
    
    
    $insert = mysqli_query($conn, "insert into pesanan ( idpelanggan ) values ('$idpelanggan')");

    if($insert){
        header('location:index.php');
    } else {
        echo '
        <script>alert(" Gagal Menambah pesanan Baru ");
        window.location.href="index.php"
        </script>
        ';
    }
}

if (isset($_POST['addproduk'])) {
    // Pastikan semua input telah di-set dan tidak kosong
    if (isset($_POST['idProduk'], $_POST['qty'], $_POST['idp']) && !empty($_POST['idProduk']) && !empty($_POST['qty']) && !empty($_POST['idp'])) {
        // Ambil nilai dari POST
        $idProduk = $_POST['idProduk'];
        $qty = (int)$_POST['qty']; // Casting qty ke integer
        $idp = $_POST['idp'];

        // Mengambil data produk
        $cekstok = mysqli_query($conn, "SELECT * FROM produk WHERE idProduk = '$idProduk'");
        if ($cekstok) {
            $ambilstok = mysqli_fetch_array($cekstok);
            if ($ambilstok) {
                $stok = $ambilstok['stok'];

                // Cek apakah stok cukup
                if ($stok >= $qty) {
                    // Kurangi stok
                    $newstok = $stok - $qty;
                    $update = mysqli_query($conn, "UPDATE produk SET stok = '$newstok' WHERE idProduk = '$idProduk'");
                    
                    // Tambahkan ke detailpesanan
                    $insert = mysqli_query($conn, "INSERT INTO detailpesanan (idPesanan, idProduk, qty) VALUES ('$idp', '$idProduk', '$qty')");

                    if ($update && $insert) {
                        echo '<script>alert("Barang berhasil ditambahkan"); window.location.href="view.php?idp='.$idp.'";</script>';
                    } else {
                        echo '<script>alert("Gagal menambahkan barang"); window.location.href="view.php?idp='.$idp.'";</script>';
                    }
                } else {
                    echo '<script>alert("Stok tidak cukup"); window.location.href="view.php?idp='.$idp.'";</script>';
                }
            } else {
                echo '<script>alert("Produk tidak ditemukan"); window.location.href="view.php?idp='.$idp.'";</script>';
            }
        } else {
            echo '<script>alert("Kesalahan query: '.mysqli_error($conn).'"); window.location.href="view.php?idp='.$idp.'";</script>';
        }
    } else {
        echo '<script>alert("Data tidak lengkap"); window.location.href="view.php?idp='.$idp.'";</script>';
    }
}

// //////////////////////////////////
if(isset($_POST['barangmasuk'])){
    $idProduk = $_POST['idProduk'];
    $qty = $_POST['qty'];
    // untuk mencari stok sekarang
    $caristok= mysqli_query($conn,"select *from masuk where idproduk='$idp'");
    $caristok2=mysqli_fetch_array($caristok);
    $stoksekarang=$caristok2['stok'];

    // hitung 
    $newstok = $stoksekarang+$qty;
    $insertb = mysqli_query($conn, "insert into brgmasuk (idProduk,qty) values ('$idProduk','$qty')");
    $updatetb =mysql_query($conn,"update produk set stok='$newstok'where idproduk='$idproduk'");

    if($insertb&&$updatetb){
        header('location:masuk.php');

    } else {
        echo '
        <script>alert("Gagal");
        window.location.href="masuk.php"
        </script>
        ';
    }
}

if(isset($_POST['hapusprodukpesanan'])){
    $idp = $_POST['idp'];
    $idpr = $_POST['idpr'];
    $idorder  = $_POST['idorder'];

    $cek1 = mysqli_query($conn, "select * from detailpesanan where iddetailpesanan = ' $idp'");
    $cek2 = mysqli_fetch_array($cek1);
    $qtysekarang = $cek2['qty'];

    $cek3 = mysqli_query($conn, "select * from produk where idProduk = '$idpr'");
    $cek4 = mysqli_fetch_array($cek3);
    $stoksekarang = $cek4['stok'];

    $hitung = $stoksekarang+$qtysekarang;

    $update = mysqli_query($conn, "update produk set stok = '$hitung' where idProduk='$idpr'");
    $hapus = mysqli_query($conn, "delete from detailpesanan where idProduk='$idpr' and iddetailpesanan = '$idp'");

    if($update&&$hapus){
        header('view.php?idp='.$idorder);      
    } else {
        echo '
        <script>alert(" Gagal Menghapus Barang ");
        window.location.href="view.php?idp='.$idorder.'"
        </script>
        
        ';

    }
}

////////////////////////////   
//MEBGUBAH DATA BARANG MASUK
    // if(isset($_POST['editdatabarangmasuk'])){
    //     $qty=$_POST['qty'];
    //     $idm=$_POST['idm'];//id masuk
    //     $idp=$_POST['idp'];//tambah id produk

    //     //cari tahu qty nya sekarang berapa
    //     $caritahu=mysqli_query($conn,"select *from masuk where idmasuk='$idm'");
    //     $caritahu2=mysqli_fetch_array($caritahu);
    //     $qtysekarang=$caritahu2['qty'];

    //     //fungsi cari tahu berapa stok sekarang
    //     $caristok= mysqli_query($conn,"select *from produk where idproduk='$idp'");
    //     $caristok2=mysqli_fetch_array($caristok);
    //     $stoksekarang=$caristok2['stok'];

    //     if($qty >= $qtysekarang){
    //         //kalau inputan user lebih besar darioada qty yang dicatat
    //         //hitung selisih
    //         $selisih =$qty-$qtysekarang;
    //         $newstok=$stoksekarang-$selisih;

    //         $query1= mysqli_query($conn,"update masuk set qty='$qty' where idmasuk='$idm'");
    //         $query2= mysqli_query($conn,"update produk set stok='$newstok'where idproduk='$idp'");

    //         if($query1&&$query2){
    //             header('location ')
    //         }else{
    //             echo'
    //             <script>alert("gagal");
    //             window.location.href="masuk.php"
    //             </script>';
    //         }

    //     } else{
    //         //kalau lebih kecil
    //         //hitung selisih
    //         $selisih = $qtysekarang-$qty;
    //         $newstok=$stoksekarang-$selisih;
    //     }
    //     $query1= mysqli_query($conn,"update masuk set qty='$qty'where idmasuk='$idm'");
    //     $query2= mysqli_query($conn,"update produk set stok='$newstok'where idproduk='$idp'");
        

    //     if($query1&&$query2){
    //         header('location ')
    //     }else{
    //         echo'
    //         <script>alert("gagal");
    //         window.location.href="masuk.php"
    //         </script>';
    //     }


    // }
  //////////////////////////// 
    //hapus data barang masuk
    // if(isset($_POST('hapusdatabarangmasuk'))){
    //     $idm=$_POST('idm');
    //     $idp=$_POST('idp');
    //     //cari tahu qty nya sekarang berapa
    //     $caritahu=mysqli_query($conn,"select *from masuk where idmasuk='$idm'");
    //     $caritahu2=mysqli_fetch_array($caritahu);
    //     $qtysekarang=$caritahu2['qty'];

    //     //fungsi cari tahu berapa stok sekarang
    //     $caristok= mysqli_query($conn,"select *from masuk where idproduk='$idp'");
    //     $caristok2=mysqli_fetch_array($caristok);
    //     $stoksekarang=$caristok2['stok'];

    
    //     //hitung selisih
    //     $newstok=$stoksekarang-$qtysekarang;
    
    //     $query1= mysqli_query($conn,"delete from masuk set qty='$qty'where idmasuk='$idm'");
    //     $query2= mysqli_query($conn,"update produk set stok='$newstok'where idproduk='$idp'");
        

    //     if($query1&&$query2){
    //         header('location ')
    //     }else{
    //         echo'
    //         <script>alert("gagal");
    //         window.location.href="masuk.php"
    //         </script>
    //         ';
    //     }
    // }   
    // // hapus pesanan
    // if(isset($_POST['hapuspesanan'])){
    //     $idP = $_POST['idP'];//idpesanan

    //     $cekdata = mysqli_query($conn,"select * from detailpesanan dp where idpesanan='$idP'");

    //     while($ok=mysqli_fetch_array($cekdata)){
    //         //balikin stok
    //         $qty = $ok['qty'];
    //         $idpesanan = $ok['idpesanan'];
    //         $iddp = $ok['iddetailpesanan'];

    //         $caristok= mysqli_query($conn,"select *from masuk where idproduk='$idp'");
    //         $caristok2=mysqli_fetch_array($caristok);
    //         $stoksekarang=$caristok2['stok'];

    //         $newstok = $stoksekarang+$qty;
    //         $queryupdate= mysqli_query($conn,"update produk set stok='$newstok' where idproduk='$idproduk'");


    //         //hapus data
    //         $querydelete = mysqli_query($conn,"delete from detailpesanan where iddetailpesanan='$iddp'");

    //         //redirect
    //     }

    //     $query = mysql_query($conn,"delete from pesanan where idpesanan='$idP'");
    //     if($queryupdate && $querydelete && $query){
    //         header('location:index.php');
    //     }else {
    //         echo'
    //         <script>alert("gagal");
    //         window.location.href="index.php"
    //         </script>
    //         ';
    //     }
    // }
    //MEBGUBAH DATA DETAIL PESANAN
    // if(isset($_POST['editdetailpesanan'])){
    //     $qty=$_POST['qty'];
    //     $iddp=$_POST['iddp'];//id detail pesanan
    //     $idpr=$_POST['idpr'];// id produk
    //     $idp=$_POST['idp'];//tambah idpesanan

    //     //cari tahu qty nya sekarang berapa
    //     $caritahu=mysqli_query($conn,"select *from detailpesanan where iddetailpesananak='$iddp'");
    //     $caritahu2=mysqli_fetch_array($caritahu);
    //     $qtysekarang=$caritahu2['qty'];

    //     //fungsi cari tahu berapa stok sekarang
    //     $caristok= mysqli_query($conn,"select * from produk where idproduk='$idpr'");
    //     $caristok2=mysqli_fetch_array($caristok);
    //     $stoksekarang=$caristok2['stok'];

    //     if($qty >= $qtysekarang){
    //         //kalau inputan user lebih besar darioada qty yang dicatat
    //         //hitung selisih
    //         $selisih =$qty-$qtysekarang;
    //         $newstok=$stoksekarang-$selisih;

    //         $query1= mysqli_query($conn,"update detailpesanan set qty='$qty'where iddetailpesanan='$iddp'");
    //         $query2= mysqli_query($conn,"update produk set stok='$newstok'where idproduk='$idpr'");

    //         if($query1&&$query2){
    //             header('location:view.php?idp='.$idp )
    //         }else{
    //             echo'
    //             <script>alert("gagal");
    //             window.location.href="view.php?idp='.$idp'"
    //             </script>';
    //         }

    //     } else{
    //         //kalau lebih kecil
    //         //hitung selisih
    //         $selisih = $qtysekarang-$qty;
    //         $newstok=$stoksekarang+$selisih;
    //     }
    //     $query1= mysqli_query($conn,"update detailpesanan set qty='$qty'where iddetailpesanan='$iddp'");
    //     $query2= mysqli_query($conn,"update produk set stok='$newstok'where idproduk='$idpr'");
        

    //     if($query1&&$query2){
    //         header('location:view.php?idp='.$idp)
    //     }else{
    //         echo'
    //         <script>alert("gagal");
    //         window.location.href="view.php?idp='.$idp'"
    //         </script>';
    //     }


    // }